#!/usr/bin/env python
# coding: utf-8

# In[1]:


def fatorial(n):
    r = 1
    for i in range(1, n+1):
        r = r * i
    return r


# In[5]:


def imprimir(r):
    print('---------------------')
    print('Resultado:',r)


# In[6]:


imprimir(fatorial(50))


# In[ ]:




