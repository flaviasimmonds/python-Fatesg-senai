:orphan:

Companies
=========

.. warning::

   Since the end of 2017 characters are no longer available on the IMDb site.
   We'll continue to support the Character class for some time, but beware that its
   mostly useless, at this time.

It works mostly like the Person class. :-)

The "currentRole" attribute is always None.


As for Person/Character and Movie objects, you can test -using the "in"
operator- if a Company has worked on a given Movie.
