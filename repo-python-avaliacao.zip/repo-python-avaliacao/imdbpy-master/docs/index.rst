IMDbPY
======

.. include:: ../README.rst


.. admonition:: Disclaimer

   .. include:: ../DISCLAIMER.txt


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   usage/index
   devel/index
   faqs
   credits
   Changelog


Indices and tables
==================

- :ref:`genindex`
- :ref:`modindex`
- :ref:`search`
