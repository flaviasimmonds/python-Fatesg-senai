  IMDbPY's goodies
  ================

Useful shell scripts, especially for developers.
See the comments at the top of the files for usage and
configuration options.

download-from-s3: download the new alternative interface dataset.

s3-reduce: create smaller versions of .tsv.gz files.

applydiffs.sh: Bash script useful apply patches to a set of
IMDb's plain text data files (the old dataset).
You can use this script to apply the diffs files distributed
on a (more or less) weekly base by IMDb.

download_applydiffs.py: courtesy of Roy Stead, download and
apply diff files (especially suited for a Windows environment) for the old dataset.

reduce.sh: Bash script useful to create a "slimmed down" version
of the IMDb's plain text data files (old dataset).
It's useful to create shorter versions of the plain
text data files, to test the imdbpy2sql.py script faster.



