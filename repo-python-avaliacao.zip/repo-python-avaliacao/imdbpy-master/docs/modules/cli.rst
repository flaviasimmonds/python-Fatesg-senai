:orphan:

:mod:`imdb.cli`
===============

.. automodule:: imdb.cli
   :members:
