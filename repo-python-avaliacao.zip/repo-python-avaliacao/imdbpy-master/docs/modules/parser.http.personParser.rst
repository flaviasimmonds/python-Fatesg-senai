:orphan:

:mod:`imdb.parser.http.personParser`
====================================

.. automodule:: imdb.parser.http.personParser
   :members:
