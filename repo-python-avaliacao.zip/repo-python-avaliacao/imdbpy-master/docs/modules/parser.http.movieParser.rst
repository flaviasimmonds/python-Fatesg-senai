:orphan:

:mod:`imdb.parser.http.movieParser`
=====================================

.. automodule:: imdb.parser.http.movieParser
   :members:
