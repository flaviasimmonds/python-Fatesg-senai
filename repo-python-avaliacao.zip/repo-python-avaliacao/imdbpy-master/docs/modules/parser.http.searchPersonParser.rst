:orphan:

:mod:`imdb.parser.http.searchPersonParser`
==========================================

.. automodule:: imdb.parser.http.searchPersonParser
   :members:
