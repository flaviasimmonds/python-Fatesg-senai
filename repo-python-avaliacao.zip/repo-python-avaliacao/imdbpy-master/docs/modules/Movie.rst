:orphan:

:mod:`imdb.Movie`
=================

.. automodule:: imdb.Movie
   :members:
