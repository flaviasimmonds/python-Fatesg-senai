:orphan:

:mod:`imdb.parser.sql.alchemyadapter`
=====================================

.. automodule:: imdb.parser.sql.alchemyadapter
   :members:
